
package Switcase;

/**
 *
 * @author fah
 */
public class Limas {
    private int luas ;
    private int tinggi;
    
    public void setLuas(int Luas)
    {
     this.luas = luas;   
    }
    public void setTinggi(int Tinggi)
    {
        this.tinggi = luas ;
    }
    public int getluas()
    {
        return luas;
    }
    public int getTinggi()
    {
        return tinggi;
    }
    public double HitungVolume()
    {
        double volume;
        volume= luas*tinggi*1/3;
        return volume;
    }
}
    
 


    
    

