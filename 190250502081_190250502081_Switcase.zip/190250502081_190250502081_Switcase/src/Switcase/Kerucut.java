
package Switcase;

/**
 *
 * @author fah
 */
public class Kerucut {
     private int jari ;
    private int tinggi ;
    
    public void setjari (int jari)
    {
        this.jari = jari ;
    }
    public void set(int tinggi) 
    {
        this.tinggi = tinggi ;    
    }
    public int getjari()
    {
        return jari;
    }
    public int gettinggi()
    {
        return tinggi;
    }
    public double HitungVolume ()
    {
        double volume;
        volume = 1/3*jari*jari*tinggi;
        return volume ;
                
    }
 
    
}


