
package Switcase;

/**
 *
 * @author fah
 */
public class Prisma {
    private int tinggi;
    private int keliling;
    private int alas;
    
    public void setalas (int alas)
    {
        this.alas = alas ;
    }
      public void settinggi (int tinggi)
    {
        this.tinggi = tinggi ;
    }
      public void setkeliling (int keliling)
    {
        this.keliling = keliling ;
    }
      public int getalas()
      {
          return alas;
      }
       public int gettinggi()
      {
          return tinggi;
      }
        public int getkeliling()
      {
          return keliling; 
      }
        public double HitungVolume ()
        {
                double volume ;
                volume = (alas*tinggi)/2*tinggi ;
                return volume;
        }
        
        public double HitungLuas ()
        {
            double luas;
        int alas = 0;
            luas = (2*alas)+(keliling*tinggi);
            return luas;
        }
    
}
  

    
