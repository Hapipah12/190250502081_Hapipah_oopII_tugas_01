
package Switcase;

/**
 *
 * @author fah
 */
public class Kubus {

    static String getluas() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private int sisi;
    
    public void setsisi (int sisi)
    {
        this.sisi = sisi;
    }
    public int getsisi()
    {
        return sisi;
    }
    public double HitungLuas()
    {
        double luas;
        luas = (6*sisi) + (sisi*sisi*sisi);
        return luas;
       
    }
    public double HitungVolume ()
    {
        double Volume;
        Volume = sisi*sisi*sisi;
        return Volume ;
                
    }
    
}


    